# graph_logic.py
import heapq
import time

class Graph:
    def __init__(self):
        # Usamos un diccionario para la lista de adyacencia (para Dijkstra)
        # Formato: { 'A': [('B', 10), ('C', 5)], 'B': [] }
        self.adj = {}
        
        # Usamos una lista de tuplas para todas las aristas (para Bellman-Ford)
        # Formato: [ ('A', 'B', 10), ('A', 'C', 5) ]
        self.edges = []
        
        # Un conjunto para rastrear nodos únicos
        self.nodes = set()

    def add_node(self, node):
        """Agrega un nodo (aeropuerto) al grafo."""
        if node not in self.nodes:
            self.nodes.add(node)
            self.adj[node] = []

    def add_edge(self, u, v, weight):
        """Agrega una arista (vuelo) con costo."""
        # Asegurarse de que los nodos existan
        self.add_node(u)
        self.add_node(v)
        
        # Agregar a la lista de aristas para Bellman-Ford
        self.edges.append((u, v, weight))
        
        # Agregar a la lista de adyacencia para Dijkstra
        self.adj[u].append((v, weight))
        
        print(f"Vuelo agregado: {u} -> {v} (Costo: {weight})")

    def bellman_ford(self, start_node):
        """
        Ejecuta el algoritmo de Bellman-Ford.
        Retorna (dist, pred, has_negative_cycle, execution_time)
        """
        if start_node not in self.nodes:
            return {}, {}, False, 0.0

        start_time = time.perf_counter()
        
        num_nodes = len(self.nodes)
        dist = {node: float('inf') for node in self.nodes}
        pred = {node: None for node in self.nodes}
        dist[start_node] = 0

        # 1. Iterar V-1 veces
        for _ in range(num_nodes - 1):
            # Iterar sobre TODAS las aristas
            for u, v, w in self.edges:
                # 2. Relajación
                if dist[u] != float('inf') and dist[u] + w < dist[v]:
                    dist[v] = dist[u] + w
                    pred[v] = u

        # 3. Detectar ciclos negativos (V-ésima iteración)
        has_negative_cycle = False
        for u, v, w in self.edges:
            if dist[u] != float('inf') and dist[u] + w < dist[v]:
                has_negative_cycle = True
                print("¡CICLO NEGATIVO DETECTADO!")
                break # Se encontró un ciclo, no es necesario seguir

        end_time = time.perf_counter()
        execution_time = (end_time - start_time) * 1000 # en milisegundos

        return dist, pred, has_negative_cycle, execution_time

    def dijkstra(self, start_node):
        """
        Ejecuta el algoritmo de Dijkstra.
        Lanzará un ValueError si encuentra un peso negativo.
        Retorna (dist, pred, execution_time)
        """
        if start_node not in self.nodes:
            return {}, {}, 0.0
            
        start_time = time.perf_counter()

        dist = {node: float('inf') for node in self.nodes}
        pred = {node: None for node in self.nodes}
        dist[start_node] = 0
        
        # Cola de prioridad (min-heap)
        pq = [(0, start_node)] # (distancia, nodo)

        while pq:
            current_dist, u = heapq.heappop(pq)

            # Si ya encontramos un camino mejor, ignoramos este
            if current_dist > dist[u]:
                continue

            for v, w in self.adj[u]:
                # --- REQUISITO CLAVE ---
                # Demostrar que Dijkstra falla con pesos negativos
                if w < 0:
                    end_time = time.perf_counter()
                    execution_time = (end_time - start_time) * 1000
                    # Lanzamos una excepción que la GUI capturará
                    raise ValueError(f"Peso negativo detectado ({u}->{v}, {w}). Dijkstra no puede continuar.")
                
                if dist[u] + w < dist[v]:
                    dist[v] = dist[u] + w
                    pred[v] = u
                    heapq.heappush(pq, (dist[v], v))

        end_time = time.perf_counter()
        execution_time = (end_time - start_time) * 1000 # en milisegundos
        
        return dist, pred, execution_time

    def get_path(self, pred, target_node):
        """Reconstruye el camino desde el diccionario de predecesores."""
        if target_node not in pred or pred[target_node] is None and target_node != self.start_node_for_path:
            # Si el nodo no es alcanzable
            if self.start_node_for_path in dist and dist[target_node] == float('inf'):
                 return [] # No es alcanzable
            # Si es el nodo de inicio
            if target_node == self.start_node_for_path:
                return [target_node]
            return [] # Caso de error o nodo inalcanzable

        path = []
        curr = target_node
        
        # Para evitar bucles infinitos si hay un error
        visited_in_path = set() 

        while curr is not None:
            if curr in visited_in_path:
                 print(f"Error: Bucle detectado al reconstruir el camino para {target_node}")
                 return [] # Bucle detectado
            
            visited_in_path.add(curr)
            path.append(curr)
            
            if curr not in pred:
                print(f"Error: Nodo {curr} no en el diccionario de predecesores.")
                break # Romper si hay un problema
                
            curr = pred.get(curr) # Usar .get para evitar KeyError

        return path[::-1] # Revertir el camino

    # Un pequeño hack para que get_path sepa cuál fue el inicio
    def set_start_node_for_path(self, start_node, dist_dict):
        self.start_node_for_path = start_node
        global dist # Hace la variable dist global dentro de esta función para get_path
        dist = dist_dict