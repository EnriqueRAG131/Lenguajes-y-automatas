# main_app.py
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
import networkx as nx
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

# Importar la lógica del grafo que creamos antes
from graph_logic import Graph

class FlightApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Proyecto 3: Red de Vuelos (Bellman-Ford)")
        self.root.geometry("1200x800")

        # Inicializar el motor del grafo y el grafo de visualización
        self.graph_logic = Graph()
        self.nx_graph = nx.DiGraph() # Grafo dirigido para visualización

        # Guardar la posición de los nodos para un dibujo estable
        self.node_positions = {}

        # --- Configuración de la Interfaz ---
        self.setup_ui()

    def setup_ui(self):

        # --- Panel de Resultados (Abajo) ---
        result_frame = ttk.LabelFrame(self.root, text="Resultados y Métricas", padding="10")
        result_frame.pack(side=tk.BOTTOM, fill=tk.X, padx=10, pady=10, expand=False)
        
        self.result_text = tk.Text(result_frame, height=8, wrap=tk.WORD, font=("Consolas", 10))
        self.result_text.pack(fill=tk.BOTH, expand=True)

        # Frame principal
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.pack(fill=tk.BOTH, expand=True)

        # --- Panel de Controles (Izquierda) con Scroll ---

        # 1. Creamos un frame "contenedor" que SÍ se ajusta a la izquierda
        outer_control_frame = ttk.LabelFrame(main_frame, text="Controles", padding="10")
        outer_control_frame.pack(side=tk.LEFT, fill=tk.Y, padx=10, pady=10)

        # 2. Creamos un Canvas (lienzo) y el Scrollbar
        canvas = tk.Canvas(outer_control_frame, borderwidth=0, width=200)
        scrollbar = ttk.Scrollbar(outer_control_frame, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=scrollbar.set)

        # 3. Este es el frame INTERNO que contendrá todos los botones
        # ¡¡ NOTA: Lo llamamos 'control_frame' para que el resto del código no se rompa !!
        control_frame = ttk.Frame(canvas) 

        # 4. Magia de Tkinter para vincular el frame interno al canvas
        canvas.create_window((0, 0), window=control_frame, anchor="nw")

        # Vincula el tamaño del frame al scrollregion del canvas
        def on_frame_configure(event):
            canvas.configure(scrollregion=canvas.bbox("all"))
        control_frame.bind("<Configure>", on_frame_configure)

        

        # 5. "Empacamos" el scrollbar y el canvas en el frame exterior
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        canvas.pack(side=tk.LEFT, fill=tk.Y)

        # 1. Agregar Aeropuerto (Nodo)
        ttk.Label(control_frame, text="Aeropuerto (Nodo):").pack(anchor=tk.W)
        self.node_entry = ttk.Entry(control_frame, width=20)
        self.node_entry.pack(pady=5)
        ttk.Button(control_frame, text="Agregar Aeropuerto", command=self.add_airport).pack()

        ttk.Separator(control_frame, orient=tk.HORIZONTAL).pack(fill=tk.X, pady=10)

        # 2. Agregar Vuelo (Arista)
        ttk.Label(control_frame, text="Origen:").pack(anchor=tk.W)
        self.origin_entry = ttk.Entry(control_frame, width=20)
        self.origin_entry.pack(pady=2)

        ttk.Label(control_frame, text="Destino:").pack(anchor=tk.W)
        self.dest_entry = ttk.Entry(control_frame, width=20)
        self.dest_entry.pack(pady=2)

        ttk.Label(control_frame, text="Costo (puede ser negativo):").pack(anchor=tk.W)
        self.weight_entry = ttk.Entry(control_frame, width=20)
        self.weight_entry.pack(pady=2)
        ttk.Button(control_frame, text="Agregar Vuelo", command=self.add_flight).pack(pady=5)
        
        ttk.Separator(control_frame, orient=tk.HORIZONTAL).pack(fill=tk.X, pady=10)

        # 3. Ejecutar Algoritmos
        ttk.Label(control_frame, text="Aeropuerto de Origen (Ejecutar):").pack(anchor=tk.W)
        self.start_node_entry = ttk.Entry(control_frame, width=20)
        self.start_node_entry.pack(pady=5)

        ttk.Button(control_frame, text="Ejecutar Bellman-Ford", command=self.run_bellman_ford).pack(pady=5)
        ttk.Button(control_frame, text="Ejecutar Dijkstra", command=self.run_dijkstra).pack(pady=5)
        
        ttk.Separator(control_frame, orient=tk.HORIZONTAL).pack(fill=tk.X, pady=10)
        
        # 4. Comparación y Pruebas
        ttk.Label(control_frame, text="Pruebas de Rendimiento").pack(anchor=tk.W)
        ttk.Button(control_frame, text="Comparar Dijkstra vs Bellman-Ford", command=self.run_comparison).pack(pady=5)
        
        ttk.Separator(control_frame, orient=tk.HORIZONTAL).pack(fill=tk.X, pady=10)
        
        # Botón para limpiar
        ttk.Button(control_frame, text="Limpiar Grafo", command=self.clear_all).pack(pady=20)


        # --- Panel del Grafo (Derecha) ---
        graph_frame = ttk.LabelFrame(main_frame, text="Visualización del Grafo", padding="10")
        graph_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        self.fig = plt.Figure(figsize=(8, 6), dpi=100)
        self.ax = self.fig.add_subplot(111)

        self.canvas = FigureCanvasTkAgg(self.fig, master=graph_frame)
        self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        self.canvas.draw()
        
        

    # --- Funciones de la Interfaz ---

    def add_airport(self):
        node = self.node_entry.get().strip().upper()
        if not node:
            messagebox.showwarning("Error", "El nombre del aeropuerto no puede estar vacío.")
            return

        if node not in self.nx_graph:
            self.graph_logic.add_node(node)
            self.nx_graph.add_node(node)
            self.node_entry.delete(0, tk.END)
            self.draw_graph()
            self.log_message(f"Aeropuerto '{node}' agregado.")
        else:
            messagebox.showwarning("Error", f"El aeropuerto '{node}' ya existe.")

    def add_flight(self):
        u = self.origin_entry.get().strip().upper()
        v = self.dest_entry.get().strip().upper()
        
        try:
            # Permitir costos decimales
            weight = float(self.weight_entry.get())
        except ValueError:
            messagebox.showwarning("Error", "El costo debe ser un número (ej. 100 o -50.5).")
            return

        if not u or not v:
            messagebox.showwarning("Error", "Origen y Destino no pueden estar vacíos.")
            return

        # Agregar arista a ambos grafos
        self.graph_logic.add_edge(u, v, weight)
        
        # Si la arista ya existe en nx_graph, la actualiza
        self.nx_graph.add_edge(u, v, weight=weight)
        
        self.draw_graph()
        self.log_message(f"Vuelo agregado: {u} -> {v} (Costo: {weight})")
        
        # Limpiar campos
        self.origin_entry.delete(0, tk.END)
        self.dest_entry.delete(0, tk.END)
        self.weight_entry.delete(0, tk.END)

    def draw_graph(self, path_edges=None):
        self.ax.clear()

        # Si hay nodos nuevos, recalcular posiciones, sino, reusar las antiguas
        if len(self.node_positions) != len(self.nx_graph.nodes):
             self.node_positions = nx.kamada_kawai_layout(self.nx_graph)
             # Alternativa: nx.spring_layout(self.nx_graph)

        # Dibujo básico de nodos
        nx.draw_networkx_nodes(self.nx_graph, self.node_positions, ax=self.ax, node_color="skyblue", node_size=700)
        nx.draw_networkx_labels(self.nx_graph, self.node_positions, ax=self.ax, font_size=10)

        # Dibujo básico de aristas
        nx.draw_networkx_edges(self.nx_graph, self.node_positions, ax=self.ax, arrowstyle='->',
                               arrowsize=20, edge_color='gray', connectionstyle='arc3,rad=0.1')

        # Etiquetas de peso
        edge_labels = nx.get_edge_attributes(self.nx_graph, 'weight')
        nx.draw_networkx_edge_labels(self.nx_graph, self.node_positions, edge_labels=edge_labels, ax=self.ax, label_pos=0.3, font_size=8)

        # Resaltar el camino (si se provee)
        if path_edges:
            nx.draw_networkx_edges(self.nx_graph, self.node_positions, ax=self.ax, edgelist=path_edges,
                                   edge_color='red', width=2, arrowstyle='->', arrowsize=20,
                                   connectionstyle='arc3,rad=0.1')

        self.ax.set_title("Red de Aeropuertos")
        self.ax.axis('off') # Ocultar ejes
        self.fig.tight_layout()
        self.canvas.draw()

    def run_bellman_ford(self):
        start_node = self.start_node_entry.get().strip().upper()
        if start_node not in self.graph_logic.nodes:
            messagebox.showwarning("Error", f"El aeropuerto de origen '{start_node}' no existe.")
            return

        self.log_message(f"\n--- Ejecutando Bellman-Ford desde {start_node} ---")
        
        dist, pred, has_neg_cycle, time_ms = self.graph_logic.bellman_ford(start_node)

        if has_neg_cycle:
            # REQUISITO: Advertir al usuario
            self.log_message("[¡ADVERTENCIA!] Se detectó un ciclo negativo.", "red")
            self.log_message("Los costos de ruta más corta no son confiables (pueden tender a -infinito).")
            self.draw_graph() # Dibujar el grafo sin camino
            messagebox.showerror("Ciclo Negativo", "¡Error! Se detectó un ciclo negativo. No es posible encontrar un camino más corto confiable.")
        else:
            self.log_message(f"Bellman-Ford completado en {time_ms:.4f} ms.")
            self.log_message("Costos de ruta más corta:")
            self.log_message(self.format_distances(dist))
            
            # Dibujar el árbol de caminos más cortos
            self.highlight_path_tree(pred)

    def run_dijkstra(self):
        start_node = self.start_node_entry.get().strip().upper()
        if start_node not in self.graph_logic.nodes:
            messagebox.showwarning("Error", f"El aeropuerto de origen '{start_node}' no existe.")
            return

        self.log_message(f"\n--- Ejecutando Dijkstra desde {start_node} ---")

        try:
            dist, pred, time_ms = self.graph_logic.dijkstra(start_node)
            
            self.log_message(f"Dijkstra completado en {time_ms:.4f} ms.")
            self.log_message("Costos de ruta más corta:")
            self.log_message(self.format_distances(dist))
            
            # Dibujar el árbol de caminos más cortos
            self.highlight_path_tree(pred)

        except ValueError as e:
            # REQUISITO: Capturar la falla de Dijkstra con pesos negativos
            self.log_message(f"[FALLO] Dijkstra falló como se esperaba.", "red")
            self.log_message(f"Error: {e}")
            messagebox.showerror("Error de Dijkstra", f"Dijkstra no se puede ejecutar: {e}")
            self.draw_graph() # Limpiar el resaltado


    def run_comparison(self):
        """
        Ejecuta ambos algoritmos y compara sus tiempos.
        Esto cumple el requisito de Experimentación y Pruebas.
        """
        start_node = self.start_node_entry.get().strip().upper()
        if start_node not in self.graph_logic.nodes:
            messagebox.showwarning("Error", f"El aeropuerto de origen '{start_node}' no existe.")
            return
            
        self.log_message(f"\n--- Iniciando Comparación (Origen: {start_node}) ---")
        
        # 1. Ejecutar Bellman-Ford
        bf_dist, _, bf_neg_cycle, bf_time = self.graph_logic.bellman_ford(start_node)
        self.log_message(f"Bellman-Ford Tiempo: {bf_time:.6f} ms")
        if bf_neg_cycle:
            self.log_message("  (Resultado: Ciclo Negativo Detectado)", "red")
        else:
            self.log_message(f"  (Resultado: {self.format_distances(bf_dist, oneline=True)})")

        # 2. Ejecutar Dijkstra
        try:
            dj_dist, _, dj_time = self.graph_logic.dijkstra(start_node)
            self.log_message(f"Dijkstra Tiempo:      {dj_time:.6f} ms")
            self.log_message(f"  (Resultado: {self.format_distances(dj_dist, oneline=True)})")
            
            # Comparar resultados si ambos terminaron
            if not bf_neg_cycle and dj_dist == bf_dist:
                self.log_message("  (Resultados de Dijkstra y Bellman-Ford COINCIDEN)", "green")
            elif not bf_neg_cycle:
                 self.log_message("  (Resultados de Dijkstra y Bellman-Ford NO COINCIDEN)", "orange")

        except ValueError as e:
            self.log_message(f"Dijkstra Tiempo: N/A (Falló)")
            self.log_message(f"  (Resultado: {e})", "red")
        
        self.log_message("--- Comparación Finalizada ---")


    def clear_all(self):
        """Limpia el grafo, la lógica y la pantalla."""
        if messagebox.askyesno("Confirmar", "¿Estás seguro de que quieres borrar toda la red de vuelos?"):
            self.graph_logic = Graph()
            self.nx_graph.clear()
            self.node_positions = {}
            self.ax.clear()
            self.canvas.draw()
            self.result_text.delete('1.0', tk.END)
            self.log_message("Grafo y registros limpiados.")

    # --- Funciones de Utilidad ---

    def log_message(self, message, tag=None):
        """Agrega un mensaje al cuadro de texto de resultados, con color opcional."""
        self.result_text.configure(state='normal')
        
        if tag:
            if not hasattr(self, f"tag_{tag}"): # Definir la etiqueta si no existe
                self.result_text.tag_configure(tag, foreground=tag)
            self.result_text.insert(tk.END, message + "\n", tag)
        else:
            self.result_text.insert(tk.END, message + "\n")
            
        self.result_text.configure(state='disabled')
        self.result_text.see(tk.END) # Auto-scroll

    def format_distances(self, dist_dict, oneline=False):
        """Formatea el diccionario de distancias para una bonita impresión."""
        sep = ", " if oneline else "\n  "
        parts = []
        for node, dist in sorted(dist_dict.items()):
            cost = f"{dist:.2f}" if dist != float('inf') else "Inf (Inalcanzable)"
            parts.append(f"{node}: {cost}")
        return f"[{sep.join(parts)}]"
        
    def highlight_path_tree(self, pred_dict):
        """
        Toma el diccionario de predecesores y encuentra todas las aristas
        que forman el árbol de caminos más cortos para resaltarlas.
        """
        path_edges = []
        for node, parent in pred_dict.items():
            if parent is not None:
                # Asegurarse de que la arista existe en el grafo visual
                if self.nx_graph.has_edge(parent, node):
                    path_edges.append((parent, node))
        
        self.draw_graph(path_edges=path_edges)