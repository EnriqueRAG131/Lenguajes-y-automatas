# run.py
import tkinter as tk
from main_app import FlightApp

if __name__ == "__main__":
    # --- Configuración Inicial ---
    # Para que la GUI se vea mejor en Windows (opcional)
    try:
        from ctypes import windll
        windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        pass # No estamos en Windows o falló, no importa

    # --- Ejecutar la Aplicación ---
    root = tk.Tk()
    app = FlightApp(root)
    
    # Iniciar el bucle principal de la GUI
    root.mainloop()